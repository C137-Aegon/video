(function(root){
  'use strict';
  const PUNCT = {'，':.13, ',':.13, '；':.22, ';':.22, '：':.16, ':':.16, '。':.22, '？':.22, '?':.22, '！':.22, '!':.22, '—':.14, '…':.16};
  function fmt(time){const cs=Math.round(Math.max(0,time)*100), min=Math.floor(cs/6000), sec=Math.floor(cs/100)%60;return String(min).padStart(2,'0')+':'+String(sec).padStart(2,'0')+'.'+String(cs%100).padStart(2,'0');}
  function spoken(text){return text.replace(/NGC\s*1068/g, 'N G C 一零六八');}
  function schedule(segment, version){
    const text=spoken(segment[version]);
    const chars=Array.from(text);
    const end=version==='revised'?segment.revisedEnd:segment.end;
    const duration=end-segment.start;
    let lastVoice=chars.length-1;
    while(lastVoice>=0&&!/[\p{L}\p{N}]/u.test(chars[lastVoice]))lastVoice--;
    const pauses=chars.map((c,i)=>i<lastVoice?(PUNCT[c]||0):0);
    const weights=chars.map(c=>/[\p{L}\p{N}]/u.test(c)?(/[A-Za-z]/.test(c)?1.12:1):0);
    const pauseSum=pauses.reduce((a,b)=>a+b,0);
    const weightSum=weights.reduce((a,b)=>a+b,0);
    const pauseScale=Math.min(1,duration*.23/Math.max(pauseSum,.0001));
    const speaking=duration-pauseSum*pauseScale;
    let cursor=segment.start;
    const units=chars.map((c,i)=>{const span=weights[i]>0?speaking*weights[i]/weightSum:pauses[i]*pauseScale;const next=Math.min(end,cursor+span);const unit={char:c,start:cursor,end:next,voice:weights[i]>0};cursor=next;return unit;});
    if(units.length)units[units.length-1].end=end;
    return {text,units,end,count:weights.filter(x=>x>0).length,rate:weightSum/speaking};
  }
  function locate(segments,time,version){
    if(time<segments[0].start)return {index:0,phase:'before',remaining:segments[0].start-time};
    for(let i=0;i<segments.length;i++){
      const s=segments[i],end=version==='revised'?s.revisedEnd:s.end;
      if(time>=s.start&&time<end)return {index:i,phase:'read',remaining:end-time};
      const next=segments[i+1];
      if(time>=end&&(!next||time<next.start))return {index:i,phase:next?'gap':'tail',remaining:next?next.start-time:0};
    }
    return {index:segments.length-1,phase:'tail',remaining:0};
  }
  const api={fmt,spoken,schedule,locate};
  if(typeof module!=='undefined'&&module.exports)module.exports=api; else root.NarrationTiming=api;
})(typeof window!=='undefined'?window:globalThis);
