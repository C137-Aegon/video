(function(){
  'use strict';
  const data=window.NARRATION_DATA, T=window.NarrationTiming, $=id=>document.getElementById(id);
  const video=$('video'), list=$('segmentList');
  let version='revised', plans=[], time=0, playing=false, videoReady=false, anchor=0, anchorTime=0, anchorWall=0, objectURL=null;
  let drawnIndex=-1, drawnVersion='', lastUnit=-2, lastPhase='', liveSpans=[], rows=[];
  const esc=s=>String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const revisionHTML=s=>s.spans.map(x=>x.changed?'<span class="edit">'+esc(x.text)+'</span>':esc(x.text)).join('');
  function rebuild(){plans=data.segments.map(s=>T.schedule(s,version));drawnIndex=-1;list.replaceChildren();rows=[];for(const s of data.segments){const row=document.createElement('button');row.type='button';row.className='segmentRow';row.setAttribute('aria-label','跳到第 '+s.id+' 段，'+T.fmt(s.start));row.innerHTML='<span class="number">'+String(s.id).padStart(2,'0')+'</span><span class="mono">'+T.fmt(s.start)+'</span><span class="text">'+(version==='revised'?revisionHTML(s):esc(s.original))+'</span>';row.addEventListener('click',()=>jump(s.id-1));rows.push(row);list.append(row);}}
  function changedMask(s){
    if(version==='original')return Array.from(T.spoken(s.original)).map(()=>false);
    const raw=s.spans.flatMap(x=>Array.from(x.text).map(c=>({c,changed:x.changed})));
    const out=[];
    for(let i=0;i<raw.length;i++){
      if(raw.slice(i,i+7).map(x=>x.c).join('')==='NGC1068'){
        out.push(raw[i],{c:' ',changed:false},raw[i+1],{c:' ',changed:false},raw[i+2],{c:' ',changed:false});
        ['一','零','六','八'].forEach((c,k)=>out.push({c,changed:raw[i+3+k].changed}));i+=6;
      }else out.push(raw[i]);
    }
    return out.map(x=>x.changed);
  }
  function drawSentence(index){
    const s=data.segments[index], plan=plans[index], mask=changedMask(s);
    $('segmentLabel').textContent='第 '+String(s.id).padStart(2,'0')+' / 30 段';
    $('windowLabel').textContent=T.fmt(s.start)+' – '+T.fmt(plan.end);
    $('sceneText').textContent=s.scene;
    $('previousLine').textContent=index>0?'上一句　'+T.spoken(data.segments[index-1][version]):'开场：轻一点，带一点悬念。';
    $('nextLine').textContent=index<data.segments.length-1?T.spoken(data.segments[index+1][version]):'画面收尾，最后一句读完后留白。';
    $('pronunciation').textContent=s.id===22?'读法：N G C 一零六八':s.id===11?'人名：弗朗西斯 · 哈尔岑':s.id===21?'耀变体：yào biàn tǐ':'';
    $('speedHint').textContent='含停顿约 '+plan.rate.toFixed(1)+' 字／秒'+(plan.rate>5.5?' · 这一段偏紧，先练数字和停顿':'');
    $('currentLine').replaceChildren();
    liveSpans=plan.units.map((u,i)=>{const span=document.createElement('span');span.className='char'+(mask[i]?' changed':'')+(!u.voice?' punct':'');span.textContent=u.char;span.dataset.charIndex=i;$('currentLine').append(span);return span;});
    rows.forEach((row,i)=>{row.classList.toggle('active',i===index);row.setAttribute('aria-current',i===index?'true':'false');});
    const row=rows[index];if(row.offsetTop<list.scrollTop||row.offsetTop+row.offsetHeight>list.scrollTop+list.clientHeight)list.scrollTop=row.offsetTop-list.offsetTop-30;
    $('previousSegment').disabled=index===0;$('nextSegment').disabled=index===data.segments.length-1;
    drawnIndex=index;drawnVersion=version;lastUnit=-2;lastPhase='';
  }
  function render(){
    const position=T.locate(data.segments,time,version), s=data.segments[position.index], plan=plans[position.index];
    if(drawnIndex!==position.index||drawnVersion!==version)drawSentence(position.index);
    let index=-1;
    if(position.phase==='read')index=plan.units.findIndex(u=>u.end>u.start&&time>=u.start&&time<u.end);
    if(index!==lastUnit||position.phase!==lastPhase){
      liveSpans.forEach((span,i)=>{span.classList.toggle('done',position.phase==='gap'||position.phase==='tail'||(index>=0&&i<index));span.classList.toggle('live',i===index);});
      lastUnit=index;lastPhase=position.phase;
    }
    if(position.phase==='read'){
      const u=plan.units[index];$('stateLabel').textContent=u&&u.voice?'正在读':'轻停顿';$('currentWord').textContent=u&&u.voice?'建议读到「'+u.char+'」':'标点处稍停';
    }else if(position.phase==='before'){
      $('stateLabel').textContent='准备';$('currentWord').textContent=position.remaining.toFixed(2)+' 秒后开始';
    }else if(position.phase==='gap'){
      $('stateLabel').textContent='换气';$('currentWord').textContent=position.remaining.toFixed(2)+' 秒后接下一句';
    }else{
      $('stateLabel').textContent=time>=data.duration-.02?'练习结束':'收尾留白';$('currentWord').textContent='最后一句已读完';
    }
    $('cueFill').style.width=(Math.max(0,Math.min(1,(time-s.start)/(plan.end-s.start)))*100)+'%';
    $('timeLabel').textContent=T.fmt(time);$('seek').value=String(time);
    $('play').textContent=playing?'暂停':'播放练习';
    $('clockLabel').textContent=videoReady?'视频同步':'文字计时';
  }
  function now(){return videoReady?video.currentTime:playing?anchorTime+(performance.now()-anchorWall)/1000*Number($('rate').value):time;}
  function seek(to,updateAnchor=true){
    time=Math.max(0,Math.min(data.duration,to));anchorTime=time;anchorWall=performance.now();
    if(videoReady)video.currentTime=Math.min(time,video.duration||data.duration);
    if(updateAnchor)anchor=T.locate(data.segments,time,version).index;
    render();
  }
  function jump(index){anchor=Math.max(0,Math.min(data.segments.length-1,index));seek(data.segments[anchor].sceneStart,false);}
  async function toggle(){
    if(playing){pause();return;}
    if(time>=data.duration-.02)seek($('loop').checked?data.segments[anchor].sceneStart:0,false);
    if($('loop').checked){const s=data.segments[anchor];if(time<s.sceneStart||time>=s.sceneEnd)seek(s.sceneStart,false);}
    anchorTime=time;anchorWall=performance.now();
    if(videoReady){try{await video.play();playing=true;}catch(e){$('mediaWarning').hidden=false;$('mediaWarning').textContent='浏览器未能播放视频，请点击视频内的播放按钮，或换一个可播放的本地 MP4。';playing=false;}}
    else playing=true;
    render();
  }
  function pause(){time=now();playing=false;anchorTime=time;anchorWall=performance.now();if(videoReady)video.pause();render();}
  function tick(){
    if(playing){
      time=Math.min(data.duration,now());
      if($('loop').checked&&time>=data.segments[anchor].sceneEnd-.003){seek(data.segments[anchor].sceneStart,false);if(videoReady&&video.paused)video.play().catch(()=>pause());}
      else if(time>=data.duration-.001){time=data.duration;playing=false;if(videoReady)video.pause();}
      render();
    }
    requestAnimationFrame(tick);
  }
  $('play').addEventListener('click',toggle);
  $('seek').addEventListener('input',()=>seek(Number($('seek').value)));
  $('backSecond').addEventListener('click',()=>seek(now()-1));$('forwardSecond').addEventListener('click',()=>seek(now()+1));
  $('previousSegment').addEventListener('click',()=>jump(drawnIndex-1));$('nextSegment').addEventListener('click',()=>jump(drawnIndex+1));$('restartSegment').addEventListener('click',()=>jump(drawnIndex));
  $('loop').addEventListener('change',()=>{anchor=drawnIndex;});
  $('version').addEventListener('change',()=>{version=$('version').value;rebuild();render();});
  $('rate').addEventListener('change',()=>{time=videoReady?video.currentTime:time;anchorTime=time;anchorWall=performance.now();video.playbackRate=Number($('rate').value);render();});
  $('showVideo').addEventListener('change',()=>{$('practiceView').classList.toggle('noVideo',!$('showVideo').checked);});
  function tab(review){$('practiceView').hidden=review;$('reviewView').hidden=!review;$('practiceTab').classList.toggle('selected',!review);$('reviewTab').classList.toggle('selected',review);$('practiceTab').setAttribute('aria-pressed',String(!review));$('reviewTab').setAttribute('aria-pressed',String(review));if(review)pause();}
  $('practiceTab').addEventListener('click',()=>tab(false));$('reviewTab').addEventListener('click',()=>tab(true));
  const review=$('reviewList');
  data.segments.forEach(s=>{const article=document.createElement('article');article.className='reviewCard';article.innerHTML='<div class="reviewHeader"><span>第 '+String(s.id).padStart(2,'0')+' 段 · '+T.fmt(s.start)+'–'+T.fmt(s.revisedEnd)+'</span><button type="button">练这一段</button></div><p class="original">原稿：'+esc(s.original)+'</p><p class="revision">建议：'+revisionHTML(s)+'</p><p class="note">'+esc(s.note)+'</p>';article.querySelector('button').addEventListener('click',()=>{tab(false);$('version').value='revised';version='revised';rebuild();jump(s.id-1);window.scrollTo({top:0,behavior:'smooth'});});review.append(article);});
  data.sources.forEach(([title,url])=>{const li=document.createElement('li'),a=document.createElement('a');a.textContent=title;a.href=url;a.target='_blank';a.rel='noopener';li.append(a);$('sourceList').append(li);});
  video.addEventListener('loadedmetadata',()=>{
    const oldTime=time, wasPlaying=playing;videoReady=true;video.playbackRate=Number($('rate').value);video.currentTime=Math.min(oldTime,video.duration);time=video.currentTime;
    $('mediaStatus').textContent='已载入 · '+T.fmt(video.duration)+' · '+(video.dataset.fileName||decodeURIComponent(data.video.split('/').pop()));
    const mismatch=Math.abs(video.duration-data.duration)>.5;$('mediaWarning').hidden=!mismatch;
    $('mediaWarning').textContent=mismatch?'所选视频与稿子的 '+T.fmt(data.duration)+' 不同，时间码仍按原稿。请确认是原速完整视频。':'';
    if(wasPlaying)video.play().catch(()=>{playing=false;render();});else playing=false;render();
  });
  video.addEventListener('play',()=>{if(videoReady){playing=true;render();}});
  video.addEventListener('pause',()=>{if(videoReady){time=video.currentTime;playing=false;render();}});
  video.addEventListener('seeking',()=>{if(videoReady){time=Math.min(data.duration,video.currentTime);render();}});
  video.addEventListener('timeupdate',()=>{if(videoReady){time=Math.min(data.duration,video.currentTime);render();}});
  video.addEventListener('ended',()=>{if($('loop').checked){seek(data.segments[anchor].sceneStart,false);video.play().catch(()=>pause());}else{time=Math.min(data.duration,video.currentTime);playing=false;render();}});
  video.addEventListener('error',()=>{if(videoReady)time=video.currentTime||time;videoReady=false;anchorTime=time;anchorWall=performance.now();$('mediaStatus').textContent='视频未载入 · 可选择本地 MP4，或只练文字';render();});
  $('videoFile').addEventListener('change',()=>{const file=$('videoFile').files[0];if(!file)return;pause();if(objectURL)URL.revokeObjectURL(objectURL);videoReady=false;objectURL=URL.createObjectURL(file);video.dataset.fileName=file.name;time=0;anchor=0;video.src=objectURL;video.load();$('mediaStatus').textContent='正在载入 '+file.name;render();});
  document.addEventListener('keydown',e=>{if($('practiceView').hidden||['INPUT','SELECT','TEXTAREA','BUTTON'].includes(e.target.tagName))return;if(e.code==='Space'){e.preventDefault();toggle();}if(e.code==='ArrowLeft'){e.preventDefault();seek(now()-1);}if(e.code==='ArrowRight'){e.preventDefault();seek(now()+1);}});
  $('durationLabel').textContent=T.fmt(data.duration);$('seek').max=String(data.duration);
  rebuild();render();if(data.video) video.src=data.video;requestAnimationFrame(tick);
})();
